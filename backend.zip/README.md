# portafolio
Proyecto para la creación de un portafolio online basado en Python y Reflex.

Tendrá una vista minimalísta e intuitiva. Con un menú funcional.

En la ruta quién soy una breve descripción e imagen
